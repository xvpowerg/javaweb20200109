package tw.com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Ch3_1_Servlet_Test_Get
 */
@WebServlet("/Ch31ServletTestGet")
public class Ch3_1_Servlet_Test_Get extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static final String html= "<html>\r\n" + 
    		"<head>\r\n" + 
    		"<meta charset=\"BIG5\">\r\n" + 
    		"<title>Insert title here</title>\r\n" + 
    		"</head>\r\n" + 
    		"<body>\r\n" + 
    		"	\r\n" + 
    		"%s" +
    		"</body>\r\n" + 
    		"</html>"; 
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Ch3_1_Servlet_Test_Get() {
        super();
        // TODO Auto-generated constructor stub
    }

    
    // ����table ����k
    private void genTable(HttpServletResponse response,
    		int rowCount,int columCount) throws IOException {
    	//td���˪O
    			String columStr = "<td>%d</td>";
    			//tr���˪O
    			String rowStr = "<tr>%s</tr>";
    			//���]�ڬO2X3
    			//�̲ײ���tr�r��
    			String newRowStr = "";
    			for (int i =1;i<=rowCount;i++) {
    				//�̲ײ���td�r��
    				String newcolumStr = "";
    				for (int k = 1; k <=columCount;k++) {
    					//���ͦh��td
    					newcolumStr += String.format(columStr, k);
    				}
    				//tr�Ptd���X
    				newRowStr +=  String.format(rowStr, newcolumStr);	
    			
    			}
    			String table = 	"<table border=\"1\">" 
    							+newRowStr+
    							"</table>" ;
    			System.out.println(table);
    			String tableHtml = String.format(html, table);
    			
    			response.getWriter().print(tableHtml);
    }
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		//�@�~ 
		//���ϥΪ̿�J���r��p�U:
		//localhost:8080/Ch3_1_Form/Ch31ServletTestGet 
		//�S����J?r=2&c=3�� ���n�X�{500���~
		//�i��ܴ��ܦr  "��J�˦��p�U localhost:8080/Ch3_1_Form/Ch31ServletTestGet?r=2&c=3"
		
		//�����e�ݺ������Ѽ�r �P c ? r=2&c=3
		String row = request.getParameter("r");
		String colum = request.getParameter("c");
		
//�����ܤ��e 		
//		//����o��row�r������ �������|�X��
//		int rowCount = Integer.parseInt(row);
//		//����o��colum�r������ �������|�X�{500�� �]��colum��null
//		int columCount = Integer.parseInt(colum);
		
		int rowCount = 0,columCount = 0;
		try {
			rowCount = Integer.parseInt(row);
			columCount = Integer.parseInt(colum);
			//����Table
			genTable(response,rowCount,columCount);
		}catch(Exception ex) {			
		String errorMsg = 
					"<p>��J�˦��p�U localhost:8080/Ch3_1_Form/Ch31ServletTestGet?r=2&c=3</p>";
		String errorHtml =  
					String.format(html, errorMsg);	
		response.getWriter().
					print(errorHtml);
	
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
