package tw.com.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tw.bean.MyUser;
import com.tw.db.UserDB;

/**
 * Servlet implementation class TestDbServlet
 */
@WebServlet("/TestDbServlet")
public class TestDbServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    @Inject   
    UserDB userDb;
		
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestDbServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


    
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String nameStr = request.getParameter("name");
		String ageStr = request.getParameter("age");
		String action = request.getParameter("action");
		System.out.println(userDb);
	HttpSession session =request.getSession();
		try {
			switch(action) {
			case "query":
			List<MyUser> list = 
			           userDb.queryAll();
			session.
			setAttribute("MyUserList", list);
			response.
			sendRedirect("ShowUserInfo.jsp");
				break;
			default:
				userDb.inserUser(nameStr, ageStr);	
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("SQL:"+e);
		}
//		try {
//		Connection con =getDBConnection();
//		inserUser(nameStr,ageStr,con);
//		queryAll(con);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			System.out.println("SQLException:"+e);
//		}
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
