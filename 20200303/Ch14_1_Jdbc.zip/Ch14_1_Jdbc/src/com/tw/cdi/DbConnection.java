package com.tw.cdi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.enterprise.inject.Disposes;
import javax.enterprise.inject.Produces;
import javax.inject.Named;

public class DbConnection {
	@Produces
	private Connection getDBConnection() throws SQLException  {
		String url = "jdbc:mysql://localhost:3306/userdb?"
				+ "serverTimezone=CST&useSSL=false&"
				+ "allowPublicKeyRetrieval=true";
		String user="root";
		String password = "123456";
		return DriverManager.
		getConnection(url,user,password);
	}
	private void closeConnection(@Disposes 
			Connection con) throws SQLException{
		con.close();
	}
}
