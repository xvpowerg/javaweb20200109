package com.tw.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.tw.bean.MyUser;

@RequestScoped
public class UserDB {
	@Inject
	private Connection con;
    public void inserUser(String name,String age) throws SQLException {
    	String sql = "INSERT INTO myuser(user_name,age) "
    			+ "VALUES('%s',%s)";
    	sql = String.format(sql, name,age);
    	System.out.println("SQL:"+sql);
    	Statement stm = con.createStatement();
    	stm.executeUpdate(sql);
    }
    public List<MyUser> queryAll()throws SQLException  {
    	Statement stm = con.createStatement();
    	List<MyUser> list = new ArrayList<>();
    	ResultSet res =  
    			stm.executeQuery("SELECT * FROM myuser");
    	while(res.next()) {
    		int id = res.getInt("id");
    		String name = res.getString("user_name");
    		int age =  res.getInt("age");
    		MyUser myUser = new MyUser(id,name,age);
    		list.add(myUser);
    		System.out.println(name+"_"+age);
    	}
    	return list;
    }
}
