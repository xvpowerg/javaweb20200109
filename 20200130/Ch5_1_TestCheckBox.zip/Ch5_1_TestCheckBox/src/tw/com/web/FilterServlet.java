package tw.com.web;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class FilterServlet
 */
@WebServlet("/FilterServlet")


public class FilterServlet extends HttpServlet {
	private String[][]  data = {
			{},
			{"Xbox","Ps5","Switch"},
			{"Jazz","Pop"},
			{"Swim","Basketball"}		
	};
	
	private void foreachArray(String[] array) {
		Stream<String> s = Stream.of(array);
		s.forEach(System.out::println);
	}
	
	//����ParameterMap ��value
	private void testParameterMap(Logger log,Map<String,String[]> map) {
		map.forEach(
				(k,v)->{
					log.info("map:"+k+":");
					foreachArray(v);	
				});
	}
	
	
	//�NHobby �ഫ�� Data��Stream
	private Stream<String> parseHobbyStream(String hobby){
		int index = Integer.parseInt(hobby);
		return Stream.of(data[index]);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		//getParameter �L�@�δN�O�I�s�FgetParameterMap ���o �}�C���Ĥ@�Ӽƭ�
		String sex = request.getParameter("sex");
		Logger log = Logger.getLogger(FilterServlet.class.getName());
		log.info("sex:"+sex);
		
		
		//�i���o�h�﫬�A���ƭ�
		String[] hobbys = 
				request.getParameterValues("hobby");
		//�z�LflatMap ��hobbys �ন������Data�r��	
	List<String>  hobbyList = Stream.<String>of(hobbys).
		flatMap(this::parseHobbyStream).
		collect(Collectors.toList());
	//getParameter �^�Ǥ@�w�O�r��
	
	//setAttribute �]�wAttribute �]�w���O Object
	//request.setAttribute(name, o);

	//�]�wgetAttribute �^�Ǫ��O Object
	//request.getAttribute(name);
	
	//request Scope(�ܼƦs�b���d��) �����P�������� �ǻ��@��

	request.setAttribute("sex", sex);
	request.setAttribute("hobbyList", hobbyList);
	request.
	getRequestDispatcher("ShowPageServlet").
	forward(request, response);

	
	
		//Map<String,String[]> map = request.getParameterMap();
		//����ParameterMap ��value
		//testParameterMap(log,map);
	
		
	


		
	}

}
