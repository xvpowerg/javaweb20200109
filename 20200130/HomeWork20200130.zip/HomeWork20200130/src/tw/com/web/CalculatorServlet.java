package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CalculatorServlet  extends HttpServlet {
	private final static String NUMBER_KEY1 = "n1";
	private final static String NUMBER_KEY2 = "n2";
	@Override
	protected void doPost(HttpServletRequest req, 
			HttpServletResponse resp) throws ServletException, IOException {
	String n1Str = 	req.getParameter(NUMBER_KEY1);
	String n2Str =  req.getParameter(NUMBER_KEY2);
	List<String> erroeMsg = new ArrayList<>();
	PrintWriter pw =  resp.getWriter();
	int n1Int = 0,n2Int = 0;
	
	
	try {
		n1Int = Integer.parseInt(n1Str);
	}catch(Exception ex) {
		erroeMsg.add("n1Int Error!:"+n1Int);
	}
		
	try {
		n2Int = Integer.parseInt(n2Str);
	}catch(Exception ex) {
		erroeMsg.add("n2Int Error!:"+n2Int);
	}
	
	if (erroeMsg.isEmpty()) {
		int ans = n1Int + n2Int;
		pw.println("Ans:"+ans);
	}else {
		erroeMsg.forEach(v->{
			pw.println(v);
			
		});
	}
		
		
		
	}

	
	
}
