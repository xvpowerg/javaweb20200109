package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TestInitParam2  extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		String imageHtmlPatent =
				"<img src=%s width='300' height='300' alt='image1'/>";
		out.println("<html>");
			out.println("<head> </head>");
			out.println("<body>");
			out.println(String.format(imageHtmlPatent, 
					getInitParameter("imageUrl_1")));		
			String url2=getServletConfig().getInitParameter("imageUrl_2");
			out.println(String.format(imageHtmlPatent, 
						url2));	
			out.println(getInitParameter("savePath"));
			out.println("</body>");
			out.println("</html>");
		
	}
	
	
	
}
