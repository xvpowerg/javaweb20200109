package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestInitParam
 */
@WebServlet(urlPatterns = "/TestInitParam",
		 initParams = {
		@WebInitParam(name="savePath",value="c:\\files"),
		@WebInitParam(name="bgColor" ,value="#ff0000")
        })
public class TestInitParam extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public TestInitParam() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out =   response.getWriter();
		String path =getInitParameter("savePath");
		out.println(path);
		String color =getInitParameter("bgColor");
		out.println(color);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
