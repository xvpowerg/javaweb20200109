package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Optional;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.util.Counter;

/**
 * Servlet implementation class ServletPage1
 */
@WebServlet("/ServletPage1")
public class ServletPage1 extends HttpServlet {
	public static final String COUNT = "count";
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletPage1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//1��C�ӭ���~~
		//2 �Ҧ��H���i�[��쪺�ϰ�
		//�N�OApplication
//	  ServletContext application = getServletContext();
//	  Optional<Integer> optInt =Optional.ofNullable(
//			 (Integer) application.getAttribute(COUNT)) ;
//	  //���] (Integer) application.getAttribute(COUNT) �� null�ɦ^��0
//	  //�_�h�N�^��key�� count�� �ƭ�
//	  int myCount = optInt.orElse(0);
//	  myCount++;
//	  application.setAttribute(COUNT, myCount);
//		PrintWriter out = response.getWriter();
//		out.println("Page1:"+myCount);		
		
//	   �ϥΪ���ʸ˫᪺���k	
		ServletContext app = getServletContext();
		Counter.increment(app);
		PrintWriter out = response.getWriter();
		out.println("Page1:"+Counter.getCount(app));
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
