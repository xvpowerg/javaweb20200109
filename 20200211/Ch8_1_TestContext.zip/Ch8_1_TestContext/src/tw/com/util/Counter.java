package tw.com.util;

import java.util.Optional;

import javax.servlet.ServletContext;

public class Counter {
	private static final String COUNT = "count";
    public static void 
    increment(ServletContext app) {
  	  int myCount = getCount(app);
  	  myCount++;
  	  app.setAttribute(COUNT,
  			  myCount);
    }
    public static int 
    getCount(ServletContext app) {
   	  Optional<Integer> optInt =
   			  Optional.ofNullable(
   		(Integer) app.getAttribute(
   				COUNT)) ;
   	  return optInt.get();
    }
    
}
