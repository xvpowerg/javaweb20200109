package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Optional;
import java.util.stream.Stream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestServlet
 */
@WebServlet("/TestServlet")
public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       //�@�~ 1 �s������������Cookie�O�d�@��
	   //�@�~ 2  ��{�i�h�H�n�J��Cookie
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    private String getCookieName(String name) {
    	return name+"_user";
    }

    private Cookie addNameCookies(HttpServletResponse response,
    		PrintWriter out,String name) {
    	Cookie cookie = new Cookie(getCookieName(name),name);
    	cookie.setMaxAge(24 * 60 * 60);
    	out.println("�w��"+name+"�Ĥ@���n�J");
    	response.addCookie(cookie);
    	this.getServletContext().getInitParameter("");
    	return null;
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//��ܤ���]�w
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out =   response.getWriter();
		String name = request.getParameter("name");
		Cookie[] cookies=  request.getCookies();
		Optional<Cookie[]> opCookies = Optional.ofNullable(cookies);
		Optional<String> opName =  Optional.ofNullable(name);
		
		//�p�Gname��null�N�^�ǰΦW
		String tmpName = opName.orElse("�ΦW");
	//�p�G Cookie ���F��F
		 if (opCookies.isPresent()) {
			 Cookie[] array = opCookies.get();
			 Stream<Cookie>  cookieStream = Stream.of(array);
		Optional<Cookie> findCookie=  cookieStream.filter(cookie->
			 cookie.getName().equals(getCookieName(name)) && 
			 cookie.getValue().equals(tmpName)).findFirst();
		
		Cookie cookie = findCookie.orElseGet(()->{
			return addNameCookies(response,out,tmpName);});
		
			if (cookie != null) {
				out.println("�w��"+cookie.getValue()+"�z�A���n�J");
			}
			
		 }else {
			 //�p�GCookies��null �s�W�@��Cookie
			 addNameCookies(response,out,tmpName); 
		 }
	}


}
