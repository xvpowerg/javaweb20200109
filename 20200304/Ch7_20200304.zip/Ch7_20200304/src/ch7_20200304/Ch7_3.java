/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200304;

/**
 *
 * @author xvpow
 */
public class Ch7_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//Boxing 只針對基本型太
	//byte Byte
	//short Short
	//int Integer *
	//long Long
	//float Float
	//double Dobule
	//char Character
	//boolean Boolean
	 //如何打包Boxing 封箱
	Integer boxingInt =  Integer.valueOf(25);
	//解封箱unBoxing
	int value = boxingInt.intValue();
	System.out.println(value);
	
	//自動封箱
	Integer boxingInt2 = 85;
	//自動解封箱
	int value2 = boxingInt2;
	
	//有考過!!
	//java.lang.NullPointerException
	Integer boxingInt3 = null;
	int value3 = boxingInt3;
	System.out.println(value3);
	
	
	
    }
    
}
