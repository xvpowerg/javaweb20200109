/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200304;

/**
 *
 * @author xvpow
 */
public class Ch7_7 {

  //Overloading 多載
    //口訣:
    //方法名稱要一樣
    //傳入的參數類型或數量不一樣
    
    static int multpi(int a1,int a2){
	return a1 * a2;
    }
    static float multpi(float f1,float f2){
	return f1 * f2;
    }
    public static void main(String[] args) {
	   System.out.println(multpi(1,2));
	   System.out.println(multpi(1.56f,2.31f));
	   System.out.println(multpi(2,5));
	  
    }
    
}
