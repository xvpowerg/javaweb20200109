/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200304;

/**
 *
 * @author xvpow
 */
public class Ch7_1 {
	
    static int max(int a,int b){
//	if (a > b){
//	    return a;
//	}else{
//	    return b;
//	}
	return a > b ? a : b;
    }
    static int min(int[] array){
	if (array == null || 
		array.length == 0){
	    System.out.println("array不可空白");
	return -1;
	}
	int min = array[0];
	for (int value : array){
	    if (value < min){
		min = value;
	    }
	}
	return min;
    }
    public static void main(String[] args) {
    //作業 1 宣告一個方法 可以傳入 2各整數 幫回傳最大值
    //作業 2 宣告一個方法 可以傳入1個整數陣列 幫我回傳最小值
    System.out.println(max(5,8));
    int [] tmp = {8,9,6,1,3};
     System.out.println(min(tmp));
    System.out.println(min(new int[]{8,9,6,1,3}));
    }
    
}
