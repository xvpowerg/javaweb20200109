/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200304;

/**
 *
 * @author xvpow
 */
public class Ch7_8 {
    //Overloading 規則
    //1 一樣類型
    //2 相同類型可相容
    //3 其他類型可相容
    //4 封箱類型
    
    //一樣類型
    static void test1(int v1){
	System.out.println("int v1");
    }
     static void test1(float v2){
	System.out.println("float v2");
    }
     //其他類型可相容
     static void test2(short s1){
	 System.out.println("short s1");
     }
     static void test2(float f2){
	 System.out.println("float f2");
     }
     
     //同類型可相容
     static void test3(long v1){
	 System.out.println("test3 long!");
     }
       static void test3(float f1){
	 System.out.println("test3 float!");
     }
       
    //4 封箱類型
    static void test4(Integer v1){
	 System.out.println("test4 Integer!");
    }   
     static void test4(Float v1){
	 System.out.println("test4 Float!");
    }   
     //封箱類型只能與基本型態類型相同
     static void test5(Float f1){
	  System.out.println("test5 Float!");
     }
    public static void main(String[] args) {
	test1(20);
	test1(25.6f);
	test2(25);//float f2
	
	test3(512);
	test4(21);
	//test5(78);//會產生錯誤
    }
    
    //作業
    //1 寫一個方法 可傳入n筆數字 或不傳入數字
     // 幫我回傳一個陣列 陣列內容為 傳入參數偶數的數字
}
