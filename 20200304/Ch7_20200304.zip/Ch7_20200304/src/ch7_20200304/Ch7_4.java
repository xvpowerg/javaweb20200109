/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200304;

/**
 *
 * @author xvpow
 */
public class Ch7_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//一定要會
	//字串 轉 整數
	int v1 = Integer.parseInt("10");
	int v2 = Integer.parseInt("50");
	System.out.println(v1 + v2);
//	String v3 = "2 5";
//	int i3 = Integer.parseInt(v3);
//	System.out.println(i3);
	
	//10進位轉2進位
	String b1 = Integer.toBinaryString(123);
	System.out.println(b1);
	//10進位轉8進位
	String oct1 = Integer.toOctalString(123);
	System.out.println(oct1);
	//10進位轉16進位
	String hex = Integer.toHexString(123);
	System.out.println(hex);
	
    }
    
}
