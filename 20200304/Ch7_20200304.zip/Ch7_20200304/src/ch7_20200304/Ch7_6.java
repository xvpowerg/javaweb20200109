/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20200304;

/**
 *
 * @author xvpow
 */
public class Ch7_6 {
    //有考過!
    //vargs 限制 只可以是最後一個參數
    static int sum(int v1,int v2,int ... numbers){
	int ans =0;
	for (int n : numbers){
	    ans += n;
	}
	return ans;
    }
    public static void main(String[] args) {
	//有一個參數 可以不傳 也可以傳1個以上 就可使用vargs
	System.out.println(sum(1,2,5,6,7,8,1,2));
	
    }
    
}
