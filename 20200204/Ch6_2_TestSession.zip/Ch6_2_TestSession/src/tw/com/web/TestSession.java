package tw.com.web;

import java.io.IOException;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sun.faces.util.Json.Option;

/**
 * Servlet implementation class TestSession
 */
@WebServlet("/TestSession")
public class TestSession extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestSession() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//getSession()
		//�ѼƦp�G�O true ���� Session ���s�b �إ߷ssession �æ^�� �s�b �N�^���ª�Session
		//�ѼƦp�G�O false ���� Session ���s�b ���إߦ^�� null �s�b �N�^���ª�Session
		//true  ���w�]
		//Session �� Scope �ͩR�g���O�ۨ��s����
		HttpSession session = request.getSession();
	Optional<Integer> countOption=
			Optional.ofNullable(
					(Integer)session.getAttribute("count"));
	int count = 0;
	if (countOption.isPresent()) {
	   count = countOption.get() + 1;
	}
	session.setAttribute("count", count);
	response.getWriter().append("count:"+count);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
