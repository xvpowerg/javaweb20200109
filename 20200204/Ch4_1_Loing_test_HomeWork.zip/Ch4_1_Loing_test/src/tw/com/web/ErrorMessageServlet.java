package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ErrorMessageServlet extends HttpServlet  {

	@Override
	protected void doGet(HttpServletRequest req, 
			HttpServletResponse resp) throws ServletException,
	IOException {
		PrintWriter out=resp.getWriter();
		out.println("ErrorMessage!!!");
		Optional<List<String>> listOp = 
				Optional.ofNullable(
						(List<String>)req.getAttribute("errorMsgs"));
		listOp.ifPresent(errors->
		   errors.forEach(msg->out.println(msg)));
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	PrintWriter out=resp.getWriter();
		Optional<List<String>> listOp = 
				Optional.ofNullable(
						(List<String>)req.getAttribute("errorMsgs"));
		listOp.ifPresent(errors->
		   errors.forEach(msg->out.println(msg)));
	
	}
	
	
	
		
}
