package tw.com.web;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

/**
 * Servlet implementation class TestServletLoad1
 */

//loadOnStartup �i�b�B��e���� �NServlet ��Ҥ�
//loadOnStartup ���X�@�� �S������
//�Ʀr�p������
@WebServlet(urlPatterns = {"/TestServletLoad1"},
loadOnStartup = 2)
public class TestServletLoad1 extends HttpServlet {
	private final static HashMap<Integer,String>
							map = new HashMap<>();
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestServletLoad1() {
        super();
        System.out.println("TestServletLoad1!"); 
    }


	@Override
	public void init(ServletConfig config) 
			throws ServletException {
		// TODO Auto-generated method stub
		System.out.println("init ServletConfig");
		super.init(config);
		
	}
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		
		for (int i =1;i<=5000000;i++) {
			map.put(i,"value:"+i);
		}
		System.out.println("init()");
	}
	@Override
	public void service(ServletRequest arg0, 
			ServletResponse arg1) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("service ServletRequest ServletResponse");
		super.service(arg0, arg1);
		//service((HttpServletRequest)arg0,(HttpServletResponse)arg1);
	}

	@Override
	protected void service(HttpServletRequest arg0, 
			HttpServletResponse arg1) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.
		println("service HttpServletRequest HttpServletResponse");

		super.service(arg0, arg1);
	}




	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		super.destroy();
		System.out.println("destroy!!");

	}


	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
