package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ShowInfoServlet
 */
@WebServlet("/ShowInfoServlet")
//�e�����������ӦAServlet �]�Ӧbjsp
public class ShowInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	private final String htmlTmp = "<!DOCTYPE html>\r\n" + 
			"<html>\r\n" + 
			"<head>\r\n" + 
			"<meta charset=\"BIG5\">\r\n" + 
			"<title>Insert title here</title>\r\n" + 
			"</head>\r\n" + 
			"<body>\r\n" + 
			"%s"+
			" \r\n" + 
			"</body>\r\n" + 
			"</html>";
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowInfoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	String count = 	request.getParameter("count");
	Optional<String> countOp= Optional.ofNullable(count);
	count = countOp.orElse("0");
	request.setAttribute("count", count);
	request.getRequestDispatcher("ShowInput.jsp").
	forward(request, response);
	
	//int textCount = Integer.parseInt(count);
//	PrintWriter out = response.getWriter();
//	String textInput = "<input type='text'/> <br/>";
//	String emp = "";
//	for (int i =1; i<= textCount; i++) {
//		emp += textInput;
//	}
//	 String html = String.format(htmlTmp, emp);  
//	out.println(html);
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
