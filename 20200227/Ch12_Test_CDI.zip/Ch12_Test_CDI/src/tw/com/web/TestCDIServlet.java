package tw.com.web;

import java.io.IOException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.bean.Book;
import tw.com.bean.Fly;
import tw.com.bean.IromMan;
import tw.com.bean.UserBean;

/**
 * Servlet implementation class TestCDIServlet
 */
@WebServlet("/TestCDIServlet")
public class TestCDIServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//Book b1 = new Book();
	@Inject
	Book b1 ;
	@Inject
	UserBean user;
	@Inject
	@Named("bird")
	Fly myFly;
	
	@Inject
	@Named("IromMan")
	Fly im;
	//Contexts and Dependency Injection
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestCDIServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		b1.setIsbn("INB123456");
		b1.setName("Book1");
		b1.setPrice(56);
		System.out.println(b1);
		System.out.println(user.getBook());
		myFly.flying();
		im.flying();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
