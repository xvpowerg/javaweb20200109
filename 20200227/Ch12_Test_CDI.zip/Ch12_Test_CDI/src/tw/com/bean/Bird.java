package tw.com.bean;

import javax.inject.Named;

@Named("bird")
public class Bird implements Fly {

	@Override
	public void flying() {
		System.out.println("����!!");
	}

}
