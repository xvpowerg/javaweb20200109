package tw.com.bean;

public class Book {
 private String isbn;
 private String name;
 private int price;
public String getIsbn() {
	return isbn;
}
public void setIsbn(String isbn) {
	this.isbn = isbn;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
@Override
public String toString() {
	return "Book [isbn=" + isbn + ", name=" + name + ", price=" + price + "]";
}
 
}
