package tw.com.bean;

import javax.inject.Named;

@Named("IromMan")
public class IromMan implements Fly {
	
	@Override
	public void flying() {
		System.out.println("IronMan Fly!!!");
	}

}
