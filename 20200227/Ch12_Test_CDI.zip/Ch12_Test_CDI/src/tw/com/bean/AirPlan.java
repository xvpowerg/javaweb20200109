package tw.com.bean;

import javax.inject.Named;

@Named("airplan")
public class AirPlan implements Fly {
	
	@Override
	public void flying() {
		System.out.println("��������!");
		
	}

}
