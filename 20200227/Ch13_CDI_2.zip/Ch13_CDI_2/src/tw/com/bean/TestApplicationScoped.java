package tw.com.bean;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class TestApplicationScoped {
	private String name = "ApplicationScoped";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
}
