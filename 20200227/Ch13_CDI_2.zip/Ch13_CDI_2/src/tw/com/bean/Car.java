package tw.com.bean;

@tw.com.annotation.Car
public class Car implements Run {
	@Override
	public void runing() {
		System.out.println("Car Runing.....");
		
	}

}
