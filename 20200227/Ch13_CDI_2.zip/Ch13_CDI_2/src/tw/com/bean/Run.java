package tw.com.bean;

public interface Run {
    void runing();
}
