package tw.com.bean;

//�@�~ Horse ��Qualifier
public class Horse implements Run{
	@Override
	public void runing() {
		System.out.println("Horse Run!!!");
	}

}
