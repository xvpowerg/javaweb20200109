package tw.com.bean;

import java.util.TreeSet;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

@RequestScoped
public class TestRequestScope {
	private String name = "RequestScope";
	@Inject
	@Named("getSet")
	TreeSet<Integer> mySet;
	@Override
	public String toString() {
		
		return "TestRequestScope [name=" + name + "]+mySet:"+mySet;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
