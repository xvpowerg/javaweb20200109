package tw.com.bean;

import javax.inject.Inject;

public class TestScope {
	@Inject
	TestRequestScope trs;//���ۦP��request�~�|���@��
	@Inject
	TestSessionScope tss;
	@Inject
	TestApplicationScoped tas;
	
	
	public void setValue(String name) {
		trs.setName(name);
	}
	public String getValue() {
		return trs.getName();
	}
	
	public void setSessionValue(String name) {
		tss.setSessionName(name);
	}
	
	public String getSessionValue() {
		return  tss.getSessionName();
	}
	
	public void setApplicationValue(String name) {
		tas.setName(name);
	}
	
	public String getApplicationValue() {
		return  tas.getName();
	}
	
}
