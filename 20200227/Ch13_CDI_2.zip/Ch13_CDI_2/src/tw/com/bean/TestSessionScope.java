package tw.com.bean;

import java.io.Serializable;

import javax.enterprise.context.SessionScoped;

@SessionScoped
public class TestSessionScope 
			implements Serializable {
	private String sessionName;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

	public String getSessionName() {
		return sessionName;
	}

	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}
	
	
	
}
