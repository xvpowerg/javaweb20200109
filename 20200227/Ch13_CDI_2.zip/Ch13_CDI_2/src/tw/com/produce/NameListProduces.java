package tw.com.produce;

import java.util.ArrayList;

import javax.enterprise.inject.Produces;
import javax.inject.Named;

public class NameListProduces {
   @Produces 
   @Named("getNames")
	public ArrayList<String> getNames(){
		ArrayList<String> list = new ArrayList<>();
		list.add("Ken");
		list.add("Vivin");
		list.add("Lindy");
		return list;
	}
   
   @Produces
   @Named("getFruit")
	public ArrayList<String> getFruit(){
		ArrayList<String> list = new ArrayList<>();
		list.add("Apple");
		list.add("Banana");
		list.add("Charry");
		return list;
	}
	
}
