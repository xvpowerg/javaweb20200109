package tw.com.produce;

import java.util.TreeSet;

import javax.enterprise.inject.Disposes;
import javax.enterprise.inject.Produces;
import javax.inject.Named;

public class TestScopedProduces {
	@Produces
	@Named("getSet")
	private TreeSet<Integer> getSet() {
		TreeSet<Integer> set= new TreeSet<>();
		set.add(100);
		set.add(98);
		set.add(70);
		System.out.println("set TreeSet");
		return set;
	}
	
	private void clearTreeSet(@Disposes @Named("getSet") TreeSet<Integer> set) {
		System.out.println("clearTreeSet!");
		set.clear();
	}
	
}
