package tw.com.web;

import java.io.IOException;
import java.util.ArrayList;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.annotation.Car;
import tw.com.bean.Run;
import tw.com.bean.TestRequestScope;
import tw.com.bean.TestScope;

/**
 * Servlet implementation class TestCDIServlet
 */
@WebServlet("/TestCDIServlet")
public class TestCDIServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	@Inject
	@Car
	Run myRun;
	
	@Inject
	@Named("getNames")
	ArrayList<String> list;
	
	@Inject
	TestScope trs;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestCDIServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		myRun.runing();
//		list.forEach(System.out::println);
		
		//Test RequestScoped
		trs.setValue("Ken");
		System.out.println(trs+":"+trs.getValue());
		//Test SessionScoped
		trs.setSessionValue("Session Vivin");
		System.out.println("Session 1:"+
		     trs.getSessionValue());
		//Test ApplicationScoped
		trs.setApplicationValue("Application Join");
		System.out.println("Application 1:"+
			     trs.getApplicationValue());
		//����Session ApplicationScoped!! �ϥ�  sendRedirect
		response.sendRedirect("TestCDIServlet2");
		
		// ����Request getRequestDispatcher
		/*request.
		getRequestDispatcher("/TestCDIServlet2").
		forward(request, response);*/
		
		//System.out.println(list.size());
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
