package tw.com.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.inject.Qualifier;

@Qualifier
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD,//Qualifier �i�Φb��k
	ElementType.FIELD,//Qualifier �ݩ�
	ElementType.TYPE, //�i�Φb���O �άO ����
	ElementType.PARAMETER})  //�i�Φb��k���ѼƤW
public @interface Car {

}
