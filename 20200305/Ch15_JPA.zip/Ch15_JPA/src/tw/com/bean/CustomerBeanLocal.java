package tw.com.bean;

import java.util.List;

import javax.ejb.Local;

import tw.com.entire.Customer;

@Local
public interface CustomerBeanLocal {
	Customer createCustomer(String name,int age);
	List<Customer> queryAllCustomer();
}
