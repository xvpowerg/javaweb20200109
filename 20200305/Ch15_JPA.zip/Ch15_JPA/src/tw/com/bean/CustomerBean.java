package tw.com.bean;

import java.util.List;

import javax.ejb.Stateless;

import tw.com.entire.Customer;

/**
 * Session Bean implementation class CustomerBean
 */
@Stateless
public class CustomerBean implements CustomerBeanLocal {
//@Stateless ���A���ӷP
//�b�o��Bean ���i�s���ݩ�
//�i���\�૬��	
    /**
     * Default constructor. 
     */
    public CustomerBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public Customer createCustomer(String name, int age) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> queryAllCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

}
