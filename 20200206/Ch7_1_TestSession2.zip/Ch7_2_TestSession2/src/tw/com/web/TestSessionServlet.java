package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Optional;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;

/**
 * Servlet implementation class TestSessionServlet
 */
@WebServlet("/TestServelt")
public class TestSessionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestSessionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("name");
		String score = request.getParameter("score");
		String out = request.getParameter("out");
		PrintWriter pw =  response.getWriter();
		HashMap<String,Integer> map;
	
		HttpSession session =  request.getSession();
		map = (HashMap)session.getAttribute("scoreMap");
		//���O�� 
		//�H�U�ר� �p�G���m10�� Session id�N�|����
		//session.setMaxInactiveInterval(10);
		//�Ʊ�session id�ߨ����
		//invalidate()
		//�n�XSession
		if (out != null) {
			session.invalidate();
		}
		pw.println("Session Id:"+session.getId());
		//�i�H��@�� �ରLocalDateTime
		LocalDateTime  creteDataTIme = 
				Instant.ofEpochMilli(session.getCreationTime()).
					atZone(ZoneId.systemDefault()).
					toLocalDateTime();
		LocalDateTime  lastAccessedDataTIme = 
				Instant.ofEpochMilli(session.getLastAccessedTime()).
					atZone(ZoneId.systemDefault()).
					toLocalDateTime();
		
		pw.println("Session Create:"+creteDataTIme);
		pw.println("Session Id:"+lastAccessedDataTIme);
		Optional<HashMap<String,Integer>> scoreOption=
				Optional.ofNullable(map);
		//�p�G���s�b�N  new HashMap �Ф@�ӷs��HashMap
		 //�åB�g�JSession
		//�p�G�s�b�N �������e��map
		map = scoreOption.orElseGet(()->{
			HashMap<String,Integer> tmpMap = new HashMap<>();
			session.setAttribute("scoreMap", tmpMap);
			return tmpMap;
		});
		
		map.put(name, Integer.parseInt(score));
		map.forEach((k,v)->{
			pw.println(k+":"+v);
		});
	
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
