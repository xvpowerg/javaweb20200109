package tw.com.listener;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import java.time.LocalDateTime;

@WebListener
public class MyHttpSessionListener 
		implements HttpSessionListener {
	@Override
	public void sessionCreated(HttpSessionEvent se) {
		LocalDateTime loginTime = LocalDateTime.now();
		System.out.println("Login Time:"+loginTime);
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent se) {
		LocalDateTime logoutTime = LocalDateTime.now();
		System.out.println("Logout Time:"+logoutTime);
	}
	
}
