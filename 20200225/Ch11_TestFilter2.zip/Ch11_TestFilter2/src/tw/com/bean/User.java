package tw.com.bean;

public class User {
	private String name;
	private String addr;
	private String phoneNumber;
	public User(String name, String addr, String phoneNumber) {
		super();
		this.name = name;
		this.addr = addr;
		this.phoneNumber = phoneNumber;
	}
	public String getName() {
		return name;
	}
	public String getAddr() {
		return addr;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	
	
}
