package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Ch2_1Servlet
 */
@WebServlet("/Ch21Servlet")
public class Ch2_1Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	private static final String HTMLTemplate= "<html>" + 
			"<head>"+
		    "<meta charset=\"UTF-8\"> " + 
			"<title>Insert title here</title>" + 
			"</head>\r\n" + 
			"<body> "+
			 " %s " +
			 "</body> "+
			 "</html>";
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Ch2_1Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//�]�w��UTF-8�s�X �i��ܤ���
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter pw =  response.getWriter();
		
	   String bodyValue = 	IntStream.rangeClosed(1, 4).mapToObj(
				i->String.format("<h%d>���D%d</h%d>", i,i,i)).
		collect(Collectors.joining());
	
	String html=String.format(HTMLTemplate, bodyValue);
		pw.write(html);	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
