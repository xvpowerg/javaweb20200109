package tw.com.bean;

public class MyImage {
	private String alt;
	private String id;
	public MyImage(String id,String alt) {
		super();
		this.alt = alt;
		this.id = id;
	}
	public String getAlt() {
		return alt;
	}
	
	public String getId() {
		return id;
	}
	 
	public String getFileName() {
		return "image"+this.getId()+".jpg";
	}
	@Override
	public String toString() {
		return "MyImage"
				+ " [alt=" + alt + ", id=" + id + "]";
	}
	
	
}
