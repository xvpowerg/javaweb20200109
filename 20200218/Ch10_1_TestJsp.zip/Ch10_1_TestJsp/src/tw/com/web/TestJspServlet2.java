package tw.com.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tw.com.bean.MyImage;

/**
 * Servlet implementation class TestJspServlet2
 */
@WebServlet("/TestJspServlet2")
public class TestJspServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestJspServlet2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	private List<MyImage> arrayToMyImageList(String[] ids){
		List<MyImage> list = null;
		list = Stream.of(ids).
				map(id->new MyImage(id,"img-"+id)).
				collect(Collectors.toList());
		
//		ArrayList<MyImage> list = new ArrayList<>();
//		for (String id : ids) {
//			MyImage mimg = new MyImage(id,"img-"+id);
//			list.add(mimg);
//		}
		return list;
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		String[]  selectedImg =
				request.getParameterValues("selImg");
		Optional<String[]> selectedImgOp = 
				Optional.ofNullable(selectedImg);
		 String[] selectedArray=
				 selectedImgOp.orElseGet(()->
				 new String[] {});
		 
	List list = arrayToMyImageList(selectedArray);
	HttpSession session= request.getSession();
	session.setAttribute("selectedArray",list);
	response.sendRedirect("ShowImage2.jsp");
	}
	
	
	

}
