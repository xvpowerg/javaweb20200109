package tw.com.bean;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.fasterxml.jackson.annotation.JsonSubTypes.Type;

import tw.com.entire.Customer;

/**
 * Session Bean implementation class CustomerBean
 */
@Stateless
public class CustomerBean implements CustomerBeanLocal {
//@Stateless ���A���ӷP
//�b�o��Bean ���i�s���ݩ�
//�i���\�૬��
	
	@Inject
	private EntityManager em;
    /**
     * Default constructor. 
     */
    public CustomerBean() {
        // TODO Auto-generated constructor stub
    }
    
	@Override
	public Customer createCustomer(String name, int age) {
		// TODO Auto-generated method stub
		Customer cu1 = new Customer();
		cu1.setAge(age);
		cu1.setName(name);
		em.persist(cu1);//���[�� �N�O�g�J��Ʈw
		return cu1;
	}

	@Override
	public List<Customer> queryAllCustomer() {
		// TODO Auto-generated method stub
		//�`�NCustomer �O���O�W��
	TypedQuery<Customer>query=  
			em.createQuery("SELECT c FROM Customer c",
					Customer.class);
	 List<Customer> list = query.getResultList();
	 if (list == null) list = new ArrayList<>();
		return list;
	}

	@Override
	public Customer findCustomerById(Long id) {
		// TODO Auto-generated method stub
		TypedQuery<Customer> query =
				em.createNamedQuery("findCustomeById",
						Customer.class).
		setParameter("cId", id);
		Customer customer = 
				query.getSingleResult();
		return customer;
	}

	@Override
	public Customer updateCustomer(Long id, 
			String name, 
			int age) {
		Customer c =findCustomerById(id);
		c.setName(name);
		c.setAge(age);
		return c;
	}

}
