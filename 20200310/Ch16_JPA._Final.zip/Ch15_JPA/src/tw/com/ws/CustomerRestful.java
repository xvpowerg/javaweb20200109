package tw.com.ws;

import java.util.List;

import javax.ejb.EJB;
import javax.ws.rs.GET;
import javax.ws.rs.PATCH;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.fasterxml.jackson.databind.ObjectMapper;

import tw.com.bean.CustomerBeanLocal;
import tw.com.entire.Customer;

@Path("customer")
@Produces(MediaType.APPLICATION_JSON)
public class CustomerRestful {
	private String toJson(String status,String msg,boolean msgIsString) {
		String json = "";
		if (msgIsString) {
		    json = "{\"status\": \"%s\","
				       + "\"msg\": \"%s\"}";	
		}else {
			 json = "{\"status\": \"%s\","
				       + "\"msg\": %s }";	
		}
	
	return String.format(json, status,msg);	
	}
	@EJB
	CustomerBeanLocal customerBean;
	@POST
	public String createCustomer(
			@QueryParam("name") String name,
			@QueryParam("age") int age) {
		
		try {
			Customer c =  
					customerBean.createCustomer(name, age);
			ObjectMapper mapper = new ObjectMapper();
			String json = mapper.writeValueAsString(c);
			return toJson("pass", json,false);
		}catch(Exception ex) {
			return toJson("faill",ex.toString(),true); 
		}
	
	}
	
	@GET
	@Path("all")
	public String queryAllCustomer() {
		try {
			List<Customer> list
		       = customerBean.queryAllCustomer();
			ObjectMapper objMap = new ObjectMapper();
			String json = objMap.writeValueAsString(list);
			return toJson("pass",json,false);
		}catch(Exception ex) {
			return toJson("faill",ex.toString(),true); 
		}
	}
	
	@GET
	@Path("{orderId:\\d+}")
	public String findCustomerById(
			@PathParam("orderId") Long id) {
		
		try {
			Customer c = 
					customerBean.findCustomerById(id);
			return toJson("pass",c.toString(),true);
		}catch(Exception ex) {
			return toJson("faill",ex.toString(),true); 
		}
	}
	
	@PATCH
	public String updateCustomer(@QueryParam("id") Long id,
			@QueryParam("name") String name,
			@QueryParam("age") int age ) {
		try {
			Customer c = customerBean.updateCustomer(id, name, age);
			ObjectMapper objMap = new ObjectMapper();
			String json = objMap.writeValueAsString(c);
			return toJson("pass",json,false); 
		}catch(Exception ex) {
			return toJson("faill",ex.toString(),true); 
		}
		
	}
}
