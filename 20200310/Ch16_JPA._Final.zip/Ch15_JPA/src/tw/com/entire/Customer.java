package tw.com.entire;

import java.io.Serializable;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Customer
 *
 */
//POJO
@Entity
@NamedQueries(@NamedQuery(name= "findCustomeById",
query="SELECT c FROM Customer c WHERE c.id=:cId"))
public class Customer implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id //�D��
	@GeneratedValue //�۰ʲ���
	@Column(name="customer_id") //�i�H������쪺�W��
	private Long id;
	private String name;
	private int age;
	
	public Customer() {
		super();
	}
   
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}

	public Long getId() {
		return id;
	}


	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", age=" + age + "]";
	}
	
	

}
